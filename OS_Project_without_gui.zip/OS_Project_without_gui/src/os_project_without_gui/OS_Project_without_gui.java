/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os_project_without_gui;

/**
 *
 * @author botah
 */
public class OS_Project_without_gui {

    /**
     * @param args the command line arguments
     */   public static Reader_Writer_controller controller=new Reader_Writer_controller();
    
    public static void main(String[] args) {
     
       
        new Reader("reader 1 ").start();
        new Writer("writer 1 ").start();
        new Reader("reader 2 ").start();
        new Writer("writer 2 ").start();
    }
    
}
