/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os_project_without_gui;

/**
 *
 * @author botah
 */

public class Reader extends Thread {

    public Reader (String name)
    {
        this.setName(name);
    }
    
    @Override
    public void run() {
        while (true){
      
      OS_Project_without_gui.controller.startreading();
      System.out.println("total readers after start = "+ OS_Project_without_gui.controller.readers);
      OS_Project_without_gui.controller.read();
      System.out.println("total readers after read = "+ OS_Project_without_gui.controller.readers);
    OS_Project_without_gui.controller.stopreading();
    System.out.println("total readers after stop = "+ OS_Project_without_gui.controller.readers);
    }}
     
}
