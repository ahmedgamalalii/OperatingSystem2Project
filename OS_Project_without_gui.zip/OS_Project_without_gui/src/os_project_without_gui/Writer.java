/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os_project_without_gui;

import java.util.Random;

/**
 *
 * @author botah
 */
public class Writer extends Thread{
    Random rand = new Random();
    String x;
    public Writer(String name ) {
   
        this.setName(name);
    }
    
   public void setx (String x)
   {
       this.x=x;
   }
          
  
    
     @Override
    public void run() {
         
        while (true ){
        OS_Project_without_gui.controller.startwrite();
        OS_Project_without_gui.controller.write("number= "+new Random().nextInt(20));
        OS_Project_without_gui.controller.stopwriting();
        System.out.println("total waiting writing  = "+OS_Project_without_gui.controller.waitingwriters);
        }
    
    
      
    }

}
