/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Random;

/**
 *
 * @author botah
 */
public class writer extends Thread {
    String name;
   
   public writer(String name) {
        this.name=name;
          this.setName(name);
    }
    

    @Override
    public void run() {
      
            Main.c.startwrite();
            Main.c.write("Money: ");
            Main.textArea1.append("Balance Updated by " +
                    this.name + "           Balance now is:   " +Main. c.getBalance() +"\n");
            Main.c.stopwriting();
    }
     @Override
     
    public String toString() {
        return  "Balance Updates by Thread : " + name+ " Balance now is " + Main.c.getBalance();
    }
    
    
}
