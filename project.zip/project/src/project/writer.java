/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.Random;

/**
 *
 * @author botah
 */
public class writer extends Thread {
   Random rand = new Random();
    public writer(String name ) {
   this.setName(name);
    }
    
     @Override
    public void run() {
         
        while (true ){
        Main.c.startwrite();
        Main.c.write("number= "+new Random().nextInt(20));
        Main.c.stopwriting();
        System.out.println("total waiting writing  = "+ Main.c.waitingwriters);
        }
    
    
      
    }
    
    
}
