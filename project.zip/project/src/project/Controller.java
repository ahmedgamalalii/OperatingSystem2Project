/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author botah
 */
public class Controller {
    
    boolean writing; //in case writing = true 
    int waitingwriters, readers;
    
    public synchronized void startwrite(){
       System.out.println(Thread.currentThread().getName() + "Request to write .....");
        while (writing || readers >0){//in case we find readers and writing still runing 
               
            try {
                waitingwriters++;
                 System.out.println(Thread.currentThread().getName() + "Wait .....");
                wait();
                 waitingwriters--;
                 System.out.println(Thread.currentThread().getName() + "notify .....");
            } catch (InterruptedException ex) {
              waitingwriters--;//lw 7sl interrupt waitingwriters will minus 1
                Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        writing = true; 
    }
    
    
    public  void write(String s)
    {
         System.out.println( Thread.currentThread().getName()+"strat  writing ..>>");
        Main.shared_tx.setText(s);
        System.out.println( Thread.currentThread().getName()+" finish writing ..>>");
        
    }
    
    
    public synchronized void stopwriting(){
         System.out.println( Thread.currentThread().getName()+" Stop writing  ..>>");
        writing =false ;
        System.out.println(Thread.currentThread().getName() + "notify all waiting ");
        notifyAll();
    }
    
    public synchronized  void startreading(){
         System.out.println( Thread.currentThread().getName()+" Request to read ..>>");
         
         while (writing || waitingwriters >0){
                           System.out.println( Thread.currentThread().getName()+" going to  Wait ..>>");

             try {
                 System.out.println(Thread.currentThread().getName()+" Wait  writing = "+ writing+" readers = "+ readers);
                 wait();
                  System.out.println( Thread.currentThread().getName()+" notify ..writing = "+ writing+" readers = "+ readers );
             } catch (InterruptedException ex) {
                 
                 Logger.getLogger(Controller.class.getName()).log(Level.SEVERE, null, ex);
             }
             
         }
         readers++;
} 
    public  void read(){
         System.out.println( Thread.currentThread().getName()+" start reading  ..>>");
          System.out.println(Thread.currentThread().getName()+"Reading "+ Main.shared_tx.getText() );
           System.out.println( Thread.currentThread().getName()+" finish  read  ..>>");
    }
    
    public synchronized void stopreading (){
        readers--;
         System.out.println( Thread.currentThread().getName()+" stop reading  ..>>");
        if (readers==0){
           notifyAll();
       }
    }
   
} 
