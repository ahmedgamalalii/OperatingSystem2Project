/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os_fx;

/**
 *
 * @author botah
 */  
public class Reader extends Thread {
String name;
    public Reader (String name)
    {
        this.name=name;
        this.setName(name);
    }
    
   
      
       @Override
    public void run() {
           Main.c.startreading();
          
         Main.c.textarea.appendText("Balance Viewed " + this.name +  "           Balance now is:   " + Main.c.getBalance() +"\n");
           //MainFrame.c.read();
          //System.out.println("Balance Viewed by Thread" + Thread.currentThread().getName() +
          //" Balance now is " + MainFrame.c.getBalance());
          Main.c.stopreading();
 
       
    }

    @Override
    public String toString() {
        return  "Balance Viewed by Thread" + name + " Balance now is " + Main.c.getBalance();
    }
    
    
}
    
     

