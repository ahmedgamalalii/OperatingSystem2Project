/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package os_fx;

import java.awt.Font;
import static java.nio.file.Files.size;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;



/**
 *
 * @author botah
 */
public class Main extends Application {
  
  Group root = new Group();
  Button btn=new Button();
   
   
    @Override
    public void start(Stage primaryStage) {
       
       Scene scene = new Scene(root,800,800,Color.GHOSTWHITE);
       
       btn.setLayoutX(360);
       btn.setLayoutY(200);
       btn.setText("Start");
       Label label = new Label();
       Label label1 = new Label();
       Label label2 = new Label();
       label1.setText("Num of Writers");
        label1.setLayoutX(30);
       label1.setLayoutY(100);
       TextField txtf=new TextField();
        txtf.setLayoutX(150);
       txtf.setLayoutY(100);
       label2.setText("Num of Readers");
        label2.setLayoutX(400);
       label2.setLayoutY(100);
        TextField txtf1=new TextField();
     
        txtf1.setLayoutX(530);
       txtf1.setLayoutY(100);
       
       label.setText(" Welcome in Bank System ");
       label.setLayoutX(300);
       label.setLayoutY(40);
       
       
      
      
      // TextArea txta=new TextArea();
       c.textarea.setLayoutX(100);
       c.textarea.setLayoutY(300);
       

       root.getChildren().addAll(btn,label,label1,label2,txtf,txtf1,c.textarea);
       DropShadow shadow=new DropShadow();  
       btn.addEventHandler(MouseEvent.MOUSE_ENTERED, (MouseEvent e)->{
           btn.setEffect(shadow);
       
       });
       
       btn.addEventHandler(MouseEvent.MOUSE_EXITED, (MouseEvent e)->{
           btn.setEffect(null);
       
       });
       
       btn.addEventHandler(MouseEvent.MOUSE_CLICKED, (MouseEvent e )->{
            for(int reader = 0,writer = 0;
                reader<Integer.parseInt(txtf1.getText())||writer<Integer.parseInt(txtf.getText())
                ;reader++,writer++){
            
            if(reader <Integer.parseInt(txtf1.getText()))
                {Reader r = new Reader((reader+1)+"");
                r.start();
               
                }
            if(writer < Integer.parseInt(txtf.getText()))
            {
                 Writer w = new Writer((writer+1)+"");
                 w.start();
                 
                
             
            }
          
        }
       });
       
       
       primaryStage.setScene(scene);
       primaryStage.show();
       
    }
    /**
     */
     public static ReaderWriter c=new ReaderWriter();
    public static void main(String[] args) {
        launch(args);
       
    }
    
}
